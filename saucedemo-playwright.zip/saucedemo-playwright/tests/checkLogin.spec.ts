import { test, expect } from '@playwright/test';

test('should load inventory page without redirect', async ({ page }) => {
  await page.goto('/inventory.html');
  await expect(page.locator('.inventory_list')).toBeVisible();
});
