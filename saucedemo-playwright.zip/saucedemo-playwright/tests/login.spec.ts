import { test, expect } from '@playwright/test';
import * as dotenv from 'dotenv';
dotenv.config();

test.describe('Login Feature', () => {
  test('should login successfully with valid credentials', async ({ page }) => {
    const username = process.env.SAUCE_USERNAME || 'standard_user';
    const password = process.env.SAUCE_PASSWORD || 'secret_sauce';

    await page.goto('/');
    await page.fill('#user-name', username);
    await page.fill('#password', password);
    await page.click('#login-button');
    await expect(page).toHaveURL(/.*inventory.html/);
  });

  test('should show error message with invalid credentials', async ({ page }) => {
    await page.goto('/');
    await page.fill('#user-name', 'invalid_user');
    await page.fill('#password', 'invalid_pass');
    await page.click('#login-button');
    await expect(page.locator('[data-test="error"]')).toBeVisible();
  });
});
