import { test, expect } from '@playwright/test';
import { SortPage } from '../pages/SortPage';

test.describe('Sort Feature', () => {
  test('should sort items A to Z by name', async ({ page }) => {
    const sortPage = new SortPage(page);
    await sortPage.goto();

    await sortPage.sortBy('az');
    const firstItemName = await sortPage.getFirstItemName();

    expect(firstItemName?.toLowerCase()).toContain('backpack');
    await page.pause();
  });

  test('should sort items by price from High to Low', async ({ page }) => {
    const sortPage = new SortPage(page);
    await sortPage.goto();

    await sortPage.sortBy('hilo');
    const firstItemPrice = await sortPage.getFirstItemPrice();

    expect(firstItemPrice).toContain('$49.99');
    await page.pause();
  });
});
