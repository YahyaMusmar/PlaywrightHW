import { test, expect } from '@playwright/test';
import { InventoryPage } from '../pages/InventoryPage';

test.describe('Add to Cart Feature', () => {
  test('should add item to cart and show correct count', async ({ page }) => {
    const inventoryPage = new InventoryPage(page);
    await page.goto('/inventory.html');

    await inventoryPage.addItemToCart();

    const count = await inventoryPage.cartCount();
    expect(count).toBe('1');
    await page.pause();
  });
});
