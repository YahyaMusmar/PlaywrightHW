import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests',
  timeout: 30 * 1000,
  retries: 1,
   workers: 1,
  globalSetup: require.resolve('./global-setup'),

  use: {
    baseURL: 'https://www.saucedemo.com',
    trace: 'on-first-retry',
     headless: false,
      slowMo: 1000,
  },

  projects: [
    {
      name: 'chromium',
      use: {
        ...devices['Desktop Chrome'],
        storageState: 'storageState.json',
      },
    },
    {
      name: 'firefox',
      use: {
        ...devices['Desktop Firefox'],
        storageState: 'storageState.json',
      },
    },
  ],
});


