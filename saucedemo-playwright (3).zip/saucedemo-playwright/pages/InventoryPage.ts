import { Page, Locator } from '@playwright/test';

export class InventoryPage {
  readonly page: Page;
  readonly addToCartButton: Locator;
  readonly cartBadge: Locator;

  constructor(page: Page) {
    this.page = page;
    this.addToCartButton = page.locator('button[data-test="add-to-cart-sauce-labs-backpack"]');
    this.cartBadge = page.locator('.shopping_cart_badge');
  }

  async goto() {
    await this.page.goto('/inventory.html');
  }

  async addItemToCart() {
    await this.addToCartButton.click();
  }

  async cartCount(): Promise<string | null> {
    return await this.cartBadge.textContent();
  }
}
