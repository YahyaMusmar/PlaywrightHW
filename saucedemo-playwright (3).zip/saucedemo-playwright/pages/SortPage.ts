import { Page, Locator } from '@playwright/test';

export class SortPage {
  readonly page: Page;
  readonly sortDropdown: Locator;
  readonly firstItemName: Locator;
  readonly firstItemPrice: Locator;

  constructor(page: Page) {
    this.page = page;
    this.sortDropdown = page.locator('[data-test="product-sort-container"]');
    this.firstItemName = page.locator('.inventory_item_name').first();
    this.firstItemPrice = page.locator('.inventory_item_price').first();
  }

  async goto() {
    await this.page.goto('/inventory.html');
  }

  async sortBy(option: 'az' | 'hilo') {
    await this.sortDropdown.waitFor({ state: 'visible', timeout: 5000 });

    if (option === 'az') {
      await this.sortDropdown.selectOption('az');
    } else if (option === 'hilo') {
      await this.sortDropdown.selectOption('hilo');
    }
  }

  async getFirstItemName(): Promise<string | null> {
    return await this.firstItemName.textContent();
  }

  async getFirstItemPrice(): Promise<string | null> {
    return await this.firstItemPrice.textContent();
  }
}
