import { Page, Locator } from '@playwright/test';

export class RemovePage {
  readonly page: Page;
  readonly addToCartButton: Locator;
  readonly removeFromCartButton: Locator;
  readonly cartBadge: Locator;

  constructor(page: Page) {
    this.page = page;
    this.addToCartButton = page.locator('button[data-test="add-to-cart-sauce-labs-backpack"]');
    this.removeFromCartButton = page.locator('button[data-test="remove-sauce-labs-backpack"]');
    this.cartBadge = page.locator('.shopping_cart_badge');
  }

  async goToInventory() {
    await this.page.goto('/inventory.html');
  }

  async addThenRemoveItem() {
    await this.addToCartButton.click();
    await this.removeFromCartButton.click();
  }

  async cartCount(): Promise<string | null> {
    if (await this.cartBadge.isVisible()) {
      return await this.cartBadge.textContent();
    }
    return null;
  }
}
