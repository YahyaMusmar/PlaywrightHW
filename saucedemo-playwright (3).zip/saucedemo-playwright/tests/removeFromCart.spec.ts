import { test, expect } from '@playwright/test';
import { RemovePage } from '../pages/RemovePage';

test.describe('Remove from Cart Feature', () => {
  test('should remove item from cart successfully', async ({ page }) => {
    const removePage = new RemovePage(page);

    await removePage.goToInventory();
    await removePage.addThenRemoveItem();

    const count = await removePage.cartCount();
    expect(count).toBeNull();
    await page.pause();
  });
});
