import { test, expect } from '@playwright/test';
import { InventoryPage } from '../pages/InventoryPage';
import { CheckoutPage } from '../pages/CheckoutPage';

test.describe('Checkout Feature', () => {
  test('should complete checkout successfully', async ({ page }) => {
    const inventoryPage = new InventoryPage(page);
    const checkoutPage = new CheckoutPage(page);

    await inventoryPage.goto();

    await inventoryPage.addItemToCart();
    await checkoutPage.openCart();
    await checkoutPage.proceedToCheckout('John', 'Doe', '12345');

    const confirmation = await checkoutPage.getConfirmationMessage();
    expect(confirmation?.toLowerCase()).toContain('thank you for your order');
    await page.pause();
  });
});
