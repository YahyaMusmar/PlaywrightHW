import { test, expect } from '@playwright/test';
import * as dotenv from 'dotenv';
import { LoginPage } from '../pages/LoginPage';
dotenv.config();

const users = [
  {
    username: process.env.SAUCE_USERNAME ,
    password: process.env.SAUCE_PASSWORD ,
    shouldPass: true,
  },
  {
    username: 'invalid_user',
    password: 'invalid_pass',
    shouldPass: false,
  },
  {
    username: 'locked_out_user',
    password: 'invalid_pass',
    shouldPass: false,
  },
];

test.describe('Parameterized Login Feature', () => {
  let loginPage: LoginPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    await loginPage.goto();
  });

  users.forEach(({ username, password, shouldPass }) => {
    test(`Login test with username "${username}"`, async ({ page }) => {
      await loginPage.login(username, password);

      if (shouldPass) {
        await expect(page).toHaveURL(/.*inventory.html/);
      } else {
        const errorText = await loginPage.getErrorMessage();
        expect(errorText).toContain('Username and password do not match');
      }

      await page.pause();
    });
  });
});


